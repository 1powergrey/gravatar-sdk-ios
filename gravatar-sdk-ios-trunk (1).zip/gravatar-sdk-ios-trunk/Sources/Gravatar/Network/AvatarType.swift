import Foundation

public protocol AvatarType: Sendable {
    var url: String { get }
    var id: String { get }
}

extension Avatar: AvatarType {
    public var id: String {
        imageId
    }

    public var url: String {
        imageUrl
    }
}
