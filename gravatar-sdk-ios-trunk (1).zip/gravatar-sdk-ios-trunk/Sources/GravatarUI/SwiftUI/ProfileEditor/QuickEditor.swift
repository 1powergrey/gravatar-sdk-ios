import Gravatar
import SwiftUI

@available(iOS, deprecated: 16.0, renamed: "QuickEditorScopeOption", message: "This will become internal in a next major release.")
public enum QuickEditorScopeType: Sendable {
    case avatarPicker
}

@available(*, deprecated, renamed: "QuickEditorScopeOption")
public enum QuickEditorScope: Sendable {
    case avatarPicker(AvatarPickerConfiguration)

    var scopeType: QuickEditorScopeType {
        switch self {
        case .avatarPicker:
            .avatarPicker
        }
    }
}

class UnsavedChangesAlertPresentationModel: ObservableObject {
    @Published var presentAlert: Bool = false
    @Published var hasUnsavedChanges: Bool = false
}

struct QuickEditor<ImageEditor: ImageEditorView>: View {
    fileprivate typealias Constants = QuickEditorConstants

    @Environment(\.oauthSession) private var oauthSession
    @Environment(\.colorScheme) var colorScheme: ColorScheme
    @Environment(\.dynamicTypeSize) var dynamicTypeSize

    @DeviceOrientation var deviceOrientation

    @AppStorage("QuickEditor.startOAuthOnAppear") private var startOAuthOnAppear: Bool = false
    @State private var fetchedToken: String?
    @State private var isAuthenticating: Bool = false
    @State private var oauthError: OAuthError?
    @State private var safariURL: IdentifiableURL?

    /// If the QE is open with the a scope with multiple pages, this property will track which page is currently being presented.
    @State private var currentPage: QuickEditorPage

    @Binding private var isPresented: Bool
    // Declare "@StateObject"s as private to prevent setting them from a
    // memberwise initializer, which can conflict with the storage
    // management that SwiftUI provides.
    // https://developer.apple.com/documentation/swiftui/stateobject
    @StateObject private var model: AvatarPickerViewModel

    @ObservedObject private var unsavedChangesAlertPresentationModel: UnsavedChangesAlertPresentationModel

    private let externalToken: String?
    private var token: String? { externalToken ?? fetchedToken }
    private let scopeOption: QuickEditorScopeOption
    private let email: Email
    private let customImageEditor: ImageEditorBlock<ImageEditor>?
    private let updateHandler: ((QuickEditorUpdateType) -> Void)?

    init(
        email: Email,
        scopeOption: QuickEditorScopeOption,
        token: String? = nil,
        isPresented: Binding<Bool>,
        customImageEditor: ImageEditorBlock<ImageEditor>? = nil,
        updateHandler: ((QuickEditorUpdateType) -> Void)? = nil,
        unsavedChangesAlertPresentationModel: UnsavedChangesAlertPresentationModel = .init()
    ) {
        self.email = email
        self.scopeOption = scopeOption
        self._isPresented = isPresented
        self.customImageEditor = customImageEditor
        self.externalToken = token
        self.updateHandler = updateHandler
        self._model = StateObject(wrappedValue: AvatarPickerViewModel(email: email, authToken: token))
        self.unsavedChangesAlertPresentationModel = unsavedChangesAlertPresentationModel
        _currentPage = State(initialValue: scopeOption.initialPage)
    }

    let authorizationFinishedNotification = NotificationCenter.default.publisher(for: .authorizationFinished)
    let authorizationErrorNotification = NotificationCenter.default.publisher(for: .authorizationError)

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if token != nil {
                    editorView()
                } else {
                    noticeView()
                }
            }
            .gravatarNavigation(
                actionButtonDisabled: model.profileModel?.profileURL == nil,
                onDoneButtonPressed: {
                    if model.hasUnsavedChanges {
                        unsavedChangesAlertPresentationModel.presentAlert = true
                    } else {
                        isPresented = false
                    }
                },
                preferenceKey: InnerHeightPreferenceKey.self
            )
        }
        .navigationViewStyle(.stack)
        .presentSafariView(identifiableURL: $safariURL, colorScheme: colorScheme)
        .onAppear {
            fetchedToken = oauthSession.sessionToken(with: email)?.token
        }
        .onReceive(authorizationFinishedNotification) { _ in
            onAuthenticationFinished()
        }.onReceive(authorizationErrorNotification) { notification in
            guard let error = notification.object as? OAuthError else { return }
            oauthError = error
            onAuthenticationFinished()
        }
        .onChange(of: token) { newValue in
            if let newValue {
                model.update(authToken: newValue, modelToRefresh: .all)
            }
        }
        .notSavedChangesAlert(isPresented: $unsavedChangesAlertPresentationModel.presentAlert) {
            isPresented = false
        }
        .interactiveDismissDisabled(model.hasUnsavedChanges)
        .onChange(of: model.hasUnsavedChanges) { _ in
            unsavedChangesAlertPresentationModel.hasUnsavedChanges = model.hasUnsavedChanges
        }
        .preference(key: QuikcEditorCurrentPagePreferenceKey.self, value: currentPage)
        .task {
            model.refresh(modelToRefresh: .all)
        }
    }

    func avatarPickerView(config: AvatarPickerConfiguration) -> some View {
        AvatarPickerView(
            model: model,
            isPresented: $isPresented,
            contentLayoutProvider: config.contentLayout,
            customImageEditor: customImageEditor,
            tokenErrorHandler: externalToken != nil ? nil : {
                oauthSession.markSessionAsExpired(with: email)
                performAuthentication()
            },
            avatarUpdatedHandler: {
                updateHandler?(QuickEditorUpdate.Avatar())
            }
        )
    }

    @ViewBuilder
    func aboutEditorView(fields: AboutInfoField) -> some View {
        AboutEditorView(
            isPresented: $isPresented,
            model: model,
            fields: fields,
            tokenErrorHandler: externalToken != nil ? nil : {
                oauthSession.markSessionAsExpired(with: email)
                performAuthentication()
            },
            aboutUpdateHandler: { profile in
                updateHandler?(QuickEditorUpdate.AboutInfo(profile: profile))
            }
        )
        // Detects taps only on the background to avoid dismissing the keyboard when tapping in a text field.
        .background(Color.clear.onTapGesture {
            model.isKeyboardPresented = false
        })
    }

    @MainActor
    @ViewBuilder
    func editorView() -> some View {
        profileCardHeaderView()
            .simultaneousGesture(TapGesture().onEnded {
                model.isKeyboardPresented = false
            })
        switch scopeOption.scope {
        case .avatarPicker(let config):
            avatarPickerView(config: config)
        case .aboutInfoEditor(let config):
            aboutEditorView(fields: config.fields)
        case .avatarPickerAndAboutInfoEditor(let config):
            switch currentPage {
            case .avatarPicker:
                avatarPickerView(config: .init(contentLayout: config.contentLayout))
            case .aboutEditor:
                aboutEditorView(fields: config.fields)
            }
        }
    }

    private func profileView() -> some View {
        AvatarPickerProfileViewWrapper(
            avatarID: $model.avatarIdentifier,
            forceRefreshAvatar: $model.forceRefreshAvatar,
            model: $model.profileModel,
            isLoading: $model.isProfileLoading,
            safariURL: $safariURL,
            buttonsMode: .constant(avatarProfileViewButtonMode),
            buttonTapHandler: profileButtonHandler
        )
        .padding(.top, AvatarPicker.Constants.profileViewTopSpacing / 2)
        .padding(.bottom, AvatarPicker.Constants.vStackVerticalSpacing)
        .padding(.horizontal, AvatarPicker.Constants.horizontalPadding)
    }

    func profileButtonHandler(_ mode: AvatarPickerProfileViewWrapper.ButtonsMode) {
        withAnimation {
            switch mode {
            case .avatar:
                currentPage = .avatarPicker
            case .aboutInfo:
                currentPage = .aboutEditor
            }
        }
    }

    var avatarProfileViewButtonMode: AvatarPickerProfileViewWrapper.ButtonsMode? {
        guard case .avatarPickerAndAboutInfoEditor = scopeOption.scope else {
            return nil
        }
        // We show the opposite button on the card, so the button mode corresponds to the opposite current page being displayed
        switch currentPage {
        case .avatarPicker:
            return .aboutInfo
        case .aboutEditor:
            return .avatar
        }
    }

    var shouldHideProfileCardHeader: Bool {
        let screenHeight = UIScreen.main.bounds.height
        let iPhoneSE3rdGenScreenHeight: CGFloat = 667

        return model.isKeyboardPresented && (
            deviceOrientation == .landscape ||
                screenHeight <= iPhoneSE3rdGenScreenHeight ||
                dynamicTypeSize >= .accessibility3
        )
    }

    @ViewBuilder
    func profileCardHeaderView() -> some View {
        if !shouldHideProfileCardHeader {
            if fetchedToken != nil {
                EmailText(email: model.email)
                    .accumulateIntrinsicHeight()
            }
            profileView()
                .dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                .accumulateIntrinsicHeight()
        } else {
            EmptyView()
        }
    }

    func noticeView() -> some View {
        VStack(spacing: 0) {
            if !isAuthenticating {
                QuickEditorNoticeView(
                    email: email,
                    token: Binding(
                        get: { token },
                        set: { fetchedToken = $0 }
                    ),
                    oauthError: $oauthError,
                    model: model,
                    safariURL: $safariURL,
                    proceedAction: {
                        startOAuthOnAppear = true
                        performAuthentication()
                    }
                )
                .padding(.horizontal, AvatarPicker.Constants.horizontalPadding)
                .accumulateIntrinsicHeight()

                // Do not use `.accumulateIntrinsicHeight()` on `Spacer()`
                // Spacer's height will auto-increase and fill the gap that is
                // left from the default initial height of the bottom sheet,
                // causing the bottom sheet to stuck in that height.
                Spacer(minLength: 0)
            } else {
                ProgressView()
                    .accumulateIntrinsicHeight()
            }
        }
        .task(id: email) {
            await model.fetchProfile()
        }
        .task {
            if startOAuthOnAppear {
                performAuthentication()
            }
        }
    }

    @MainActor
    func performAuthentication() {
        Task {
            isAuthenticating = true
            if !oauthSession.hasValidSession(with: email) {
                do {
                    try await oauthSession.retrieveAccessToken(with: email)
                } catch OAuthError.oauthResponseError(_, let code) where code == .canceledLogin {
                    // ignore the error if the user has cancelled the operation.
                } catch let error as OAuthError {
                    oauthError = error
                } catch {
                    oauthError = nil
                }
            }
            onAuthenticationFinished()
        }
    }

    func onAuthenticationFinished() {
        if let fetchedToken = oauthSession.sessionToken(with: email)?.token {
            self.fetchedToken = fetchedToken
            oauthError = nil
        }
        isAuthenticating = false
    }
}

extension View {
    fileprivate func notSavedChangesAlert(
        isPresented: Binding<Bool>,
        onDiscard: @escaping () -> Void
    ) -> some View {
        self.alert(QuickEditorConstants.Localized.UnsavedChangesAlert.title, isPresented: isPresented) {
            Button {} label: {
                Text(QuickEditorConstants.Localized.UnsavedChangesAlert.keepEditingButtonTitle)
            }
            Button {
                onDiscard()
            } label: {
                Text(QuickEditorConstants.Localized.UnsavedChangesAlert.discardChangesButtonTitle)
            }
        } message: {
            Text(QuickEditorConstants.Localized.UnsavedChangesAlert.message)
        }
    }
}

enum QuickEditorConstants {
    enum ErrorView {
        static func title(for oauthError: OAuthError?) -> String? {
            switch oauthError {
            case .loggedInWithWrongEmail:
                Localized.WrongEmailError.title
            default:
                nil
            }
        }

        static func subtext(for oauthError: OAuthError?) -> String {
            switch oauthError {
            case .loggedInWithWrongEmail(let email):
                String(format: Localized.WrongEmailError.subtext, email)
            default:
                Localized.MissingToken.subtext
            }
        }

        static func buttonTitle(for oauthError: OAuthError?) -> String {
            Localized.MissingToken.buttonTitle
        }
    }

    enum Localized {
        enum UnsavedChangesAlert {
            static let title = SDKLocalizedString(
                "AvatarPicker.UnsavedChangesAlert.title",
                value: "Unsaved changes",
                comment: "Title of an alert advising the user that they will lose their unsaved changes if they close the quick editor"
            )
            static let message = SDKLocalizedString(
                "AvatarPicker.UnsavedChangesAlert.message",
                value: "If you leave now your changes will be lost.",
                comment: "A message advising the user that will lose their unsaved changes if they close the quick editor"
            )
            static let keepEditingButtonTitle = SDKLocalizedString(
                "AvatarPicker.UnsavedChangesAlert.keepEditingButtonTitle",
                value: "Keep editing",
                comment: "Title of the action to keep editing"
            )
            static let discardChangesButtonTitle = SDKLocalizedString(
                "AvatarPicker.UnsavedChangesAlert.discardChangesButtonTitle",
                value: "Discard",
                comment: "Title of the action to discard changes and close the quick editor"
            )
        }

        enum WrongEmailError {
            static let title = SDKLocalizedString(
                "AvatarPicker.ContentLoading.Failure.Retry.title",
                value: "Ooops",
                comment: "Title of a message advising the user that something went wrong while loading their avatars"
            )
            static let subtext = SDKLocalizedString(
                "AvatarPicker.ContentLoading.Failure.WrongEmailError.subtext",
                value: "It looks like you used the wrong email to log in. Please try again using %@ this time. Thanks!",
                comment: "A message describing the error and advising the user to login again to resolve the issue"
            )
        }

        enum MissingToken {
            static let headline = SDKLocalizedString(
                "AvatarPicker.ContentLoading.Failure.MissingToken.headline",
                value: "Edit your Profile",
                comment: "Headline of an intro screen for editing a user's profile."
            )

            static let subheadline = SDKLocalizedString(
                "AvatarPicker.ContentLoading.Failure.MissingToken.subheadline",
                value: "Enhance your %@ profile with Gravatar.",
                comment: "Subheadline of an intro screen for editing a user's profile. %@ is the name of a mobile app that uses Gravatar services."
            )

            static let buttonTitle = SDKLocalizedString(
                "AvatarPicker.Continue.title",
                value: "Continue",
                comment: "Title of a button that will proceed with the action."
            )

            static let subtext = SDKLocalizedString(
                "AvatarPicker.ContentLoading.Failure.MissingToken.subtext",
                value: "Manage your profile for the web in one place.",
                comment: "A message that informs the user about Gravatar."
            )
        }
    }
}

#Preview {
    QuickEditor<NoCustomEditor>(
        email: .init(""),
        scopeOption: .aboutEditor(.init()),
        isPresented: .constant(true)
    )
}
